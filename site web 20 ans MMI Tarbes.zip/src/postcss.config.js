module.exports = {
    plugins: [
        require('autoprefixer'),
        require('postcss-nested'),
        require('cssnano'),
        require('rucksack-css'),
        // autoprefixer: {},
        // 'postcss-nested': {},
        // cssnano: {},
        // 'rucksack-css': {},
    ]
}